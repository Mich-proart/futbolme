<?php
$carpeta='euskadi'; $territorial='24'; 


$rot='https://euskadifutbol.eus';
$url='https://euskadifutbol.eus/partidos/?idgrupo=ccc&idCompeticion=aaa&temporada=2021'; 
//$url_equipo='';

		

?>