<?php

$carpeta='00nacional';
	$urlActa='http://actas.rfef.es/actas/RFEF_CmpPartido?cod_primaria=1000144&CodActa=xxx';
	$urlActa='https://www.rfef.es/actas?pid=xxx';
	$url='https://www.rfef.es/competiciones/futbol-masculino/resultados/xxx/2020';

            $t=$temporada_id??1;

            switch ($t) {
                case 1:$baseFederacion=100;$base2=22330;break;
                case 2:$baseFederacion=101;$base2=22410;break; 
                case 3:$baseFederacion=104;$base2=22462;break; 
                case 4:$baseFederacion=105;$base2=22500;break; 
                case 5:$baseFederacion=106;$base2=22538;break; 
                case 6:$baseFederacion=107;$base2=22576;break; 


                //https://futbolfemenino.rfef.es/es/primera-iberdrola/calendario-y-resultados/?j=7&y=2020
                //https://futbolfemenino.rfef.es/es/reto-iberdrola-grupo-norte/calendario-y-resultados/?j=9&y=2020
                //https://futbolfemenino.rfef.es/es/reto-iberdrola-sur/calendario-y-resultados/?j=9&y=2020
                //https://futbolfemenino.rfef.es/es/primera-nacional-grupo-1/calendario-y-resultados/?j=9&y=2020
                //https://futbolfemenino.rfef.es/es/primera-nacional-grupo-2/calendario-y-resultados/?j=9&y=2020
                //https://futbolfemenino.rfef.es/es/primera-nacional-grupo-3/calendario-y-resultados/?j=9&y=2020
                //https://futbolfemenino.rfef.es/es/primera-nacional-grupo-4/calendario-y-resultados/?j=9&y=2020
                //https://futbolfemenino.rfef.es/es/primera-nacional-grupo-5/calendario-y-resultados/?j=9&y=2020
                //https://futbolfemenino.rfef.es/es/primera-nacional-grupo-6/calendario-y-resultados/?j=9&y=2020
                //https://futbolfemenino.rfef.es/es/primera-nacional-grupo-7/calendario-y-resultados/?j=9&y=2020

                /* 
                DHJ1 https://www.rfef.es/competiciones/futbol-masculino/resultados/22615/2020
                DHJ2 https://www.rfef.es/competiciones/futbol-masculino/resultados/22645/2020
                https://www.rfef.es/competiciones/futbol-masculino/resultados/22675/2020
                https://www.rfef.es/competiciones/futbol-masculino/resultados/22705/2020
                https://www.rfef.es/competiciones/futbol-masculino/resultados/22739/2020
                https://www.rfef.es/competiciones/futbol-masculino/resultados/23353/2020
                https://www.rfef.es/competiciones/futbol-masculino/resultados/22769/2020


                */
            }
      




	$bd='proxis';
?>