<?php
$id_temporada='71';
$rot='https://www.isquad.es/competiciones_publico.php?id_temporada='.$id_temporada.'&id_ambito='.$id_ambito.'&asdfg=1';
$url='https://www.isquad.es/competiciones_publico.php?id_temporada='.$id_temporada.'&id_competicion=aaa&id_fase=bbb&id_grupo=ccc&id_ambito='.$id_ambito.'&asdfg=1&jornada=ddd'; 
$url_equipo='https://www.isquad.es/competiciones_publico_equipo.php?id_equipo=xxx&id_grupo=ccc&id_ambito='.$id_ambito;

?>