<?php
$carpeta='murcia'; $territorial='10'; 


$rot='https://ffrm.es/es';
$url='https://ffrm.es/es/tournament/aaa/summary'; 
//$url_equipo='';

		

?>