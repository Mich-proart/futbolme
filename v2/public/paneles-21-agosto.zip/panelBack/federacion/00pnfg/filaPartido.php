<div class="tabla_rdg" style="background-color:#FFF!important;"> 
	<span class="textocolor">&nbsp;17-03-2019- 17:00</span> 
	<table cellpadding="1" cellspacing="0" border="0" width="750"> 
		<tbody>
			<tr> 
				<td align="right" width="330"> 
					<span class="subtitulos"> &nbsp; <a style="color:#000;" href="NFG_VisEquipos?cod_primaria=1000119&amp;Codigo_Equipo=52"> RACING CLUB FERROL </a> </span>
					 &nbsp; <img src="/pnfg/pimg/Clubes/thumb/00100_0000001162_escudo_racing_nuevo.jpg" align="absmiddle" width="20"> 
				</td> 
				<td align="center" width="25"> <span class="title">&nbsp; <span class="resultado_cerrada"><style>#idh149597:after{content:"\0034"}</style><span id="idh149597"></span></span> </span> 
				</td> 
				<td align="center" width="5">-</td> 
				<td align="center" width="25"> <span class="title"> <span class="resultado_cerrada">0</span> </span> 
				</td> 
				<td width="300"> <img src="/pnfg/pimg/Clubes/thumb/00100_0000000121_AROSA.png" align="absmiddle" width="20"> &nbsp;<span class="subtitulos"> <a style="color:#000;" href="NFG_VisEquipos?cod_primaria=1000119&amp;Codigo_Equipo=4323"> AROSA S.C. </a> &nbsp; </span> 
				</td> 
				<td style="font-size:10px;font-weight: bolder;color: green;" title="Penaltis" align="center" width="75px"> 
				</td> 
			</tr> 
			<tr> 
				<td colspan="6"> 
					<table cellpadding="0" cellspacing="0" border="0" width="100%"> 
						<tbody><tr> 
							<td width="121"> &nbsp; <a class="img lcab1" href="/pnfg/NFG_CmpPartido?cod_primaria=1000120&amp;CodActa=459701&amp;cod_acta=459701" onmouseover="showhint('<span class=title><b>Ver ficha del Partido</b></span>', this)">&nbsp;</a> <a style="color:#000;" href="NFG_LstComparativaEquipos?cod_primaria=5000273&amp;competicion=7219068&amp;grupo=7219115&amp;equipo1=52&amp;equipo2=4323"><img src="http://files.ffgalicia.novanet.es/pnfg/img/FGF/ESP/comparativa_equipos.png" title="Comparativa de los equipos" border="0"></a> 
							</td> 
							<td width="263<tml_else>476"> <span class="textocolor"><b>Campo:</b></span> <a href="/pnfg/NPcd/NFG_VisCampos?cod_primaria=1000122&amp;Codigo_Campo=377"> A MALATA </a> 
							</td> 
							<td> <span class="textocolor"><b>Árbitro: </b></span>CASTRO CASTRO, MIGUEL ANGEL &nbsp; 
							</td> 
						</tr> 
						<tr align="right"> <td colspan="5"> </td> </tr> 
					</tbody>
				</table> 
			</td> 
		</tr> 
	</tbody>
</table> 
</div>