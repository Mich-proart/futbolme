4-0  (el 4 sin nada) Tamaño: 1 - 68
<style>#idh21224:after{content:"0"}</style><spanid=idh21224></span>

0-2  Tamaño: 108 - 86
<style>#idh21225:after{content:"\0030"}</style><spanid=idh21225><spanstyle="display:none;">1</span></span>
<style>#idh21226:after{content:"\0030";display:none}</style><spanid=idh21226>2</span>

1-0 Tamaño: 109 - 108
<style>#idh21227:before{content:"\0031"}</style><spanid=idh21227><spanstyle="display:none;">1</span></span>
<style>#idh21228:after{content:"\0030"}</style><spanid=idh21228><spanstyle="display:none;">1</span></span>

2-0  (el 0 sin nada) Tamaño: 123 - 1
<style>#idh21229:before{content:"\0031";display:none}</style><spanid=idh21229>2<spanstyle="display:none;">1</span></span>

1-3 Tamaño: 109 - 109
<style>#idh21231:before{content:"\0031"}</style><spanid=idh21231><spanstyle="display:none;">1</span></span>
<style>#idh21232:before{content:"\0033"}</style><spanid=idh21232><spanstyle="display:none;">2</span></span>

6-1 Tamaño: 108 - 105
<style>#idh21233:after{content:"\0036"}</style><spanid=idh21233><spanstyle="display:none;">6</span></span>
<style>#idh21234:before{content:"1"}</style><spanid=idh21234><spanstyle="display:none;">1</span></span>

2-1  (el 1 sin nada) Tamaño: 122 - 1
<style>#idh21235:after{content:"\0030";display:none}</style><spanid=idh21235>2<spanstyle="display:none;">1</span></span>

0-1 (el 0 sin nada) Tamaño: 1 - 109
<style>#idh21238:before{content:"\0031"}</style><spanid=idh21238><spanstyle="display:none;">1</span></span>

0-0 Tamaño: 123 - 109
<style>#idh21239:before{content:"\0030";display:none}</style><spanid=idh21239>0<spanstyle="display:none;">1</span></span>
<style>#idh21240:before{content:"\0030"}</style><spanid=idh21240><spanstyle="display:none;">1</span></span>

1-1 Tamaño: 86 - 122
<style>#idh21241:after{content:"\0030";display:none}</style><spanid=idh21241>1</span>
<style>#idh21242:after{content:"\0030";display:none}</style><spanid=idh21242>1<spanstyle="display:none;">1</span></span>