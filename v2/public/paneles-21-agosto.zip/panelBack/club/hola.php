<?php

echo 'hola'; die;
?>