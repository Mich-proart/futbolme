<?php $static_v=3;
//$raiz="";
?>
<!DOCTYPE html>
<html lang="es">
<head>

<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<script src="//ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script async src="js/bootstrap.min.js"></script>
<link href="css/bootstrap.min.css?v=<?php echo $static_v; ?>" rel="stylesheet">
<link href="css/main.css?v=<?php echo $static_v; ?>" rel="stylesheet">
<link href="css/style.css?v=<?php echo $static_v; ?>" rel="stylesheet">

