<?php

echo 'hola'; die;
?>